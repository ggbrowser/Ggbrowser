package com.ggbrowser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.webkit.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature

class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private lateinit var address: EditText
    private lateinit var progress: ProgressBar
    private lateinit var title: TextView
    private var privateMode = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFFFFFFF.toInt())
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(10, 8, 10, 4)
        }

        fun button(text: String, action: () -> Unit): Button =
            Button(this).apply {
                this.text = text
                minWidth = 0
                setPadding(12, 0, 12, 0)
                setOnClickListener { action() }
            }

        val back = button("‹") { if (webView.canGoBack()) webView.goBack() }
        val forward = button("›") { if (webView.canGoForward()) webView.goForward() }
        val reload = button("↻") { webView.reload() }

        address = EditText(this).apply {
            hint = "Search or enter address"
            singleLine = true
            setPadding(20, 0, 20, 0)
            setBackgroundResource(android.R.drawable.editbox_background)
            setOnEditorActionListener { _, _, _ ->
                loadAddress(text.toString())
                true
            }
        }

        top.addView(back, LinearLayout.LayoutParams(48, 48))
        top.addView(forward, LinearLayout.LayoutParams(48, 48))
        top.addView(reload, LinearLayout.LayoutParams(48, 48))
        top.addView(address, LinearLayout.LayoutParams(0, 52, 1f))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 0, 8, 0)
        }

        val home = button("Home") { webView.loadUrl("https://www.google.com") }
        val desktop = button("Desktop") {
            webView.settings.userAgentString =
                if (webView.settings.userAgentString.contains("Mobile"))
                    webView.settings.userAgentString.replace(" Mobile", "")
                else
                    null
            webView.reload()
        }
        val find = button("Find") {
            val input = EditText(this)
            input.hint = "Find text"
            AlertDialog.Builder(this)
                .setTitle("Find in page")
                .setView(input)
                .setPositiveButton("Find") { _, _ -> webView.findAllAsync(input.text.toString()) }
                .setNegativeButton("Cancel", null)
                .show()
        }
        val private = button("Private") {
            privateMode = !privateMode
            if (privateMode) {
                webView.settings.cacheMode = WebSettings.LOAD_NO_CACHE
                CookieManager.getInstance().removeAllCookies(null)
                Toast.makeText(this, "Private mode enabled", Toast.LENGTH_SHORT).show()
            } else {
                webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
                Toast.makeText(this, "Private mode disabled", Toast.LENGTH_SHORT).show()
            }
        }

        actions.addView(home)
        actions.addView(desktop)
        actions.addView(find)
        actions.addView(private)

        title = TextView(this).apply {
            setPadding(14, 4, 14, 4)
            textSize = 13f
            text = "GG Browser"
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }

        webView = WebView(this)
        configureWebView()

        root.addView(top)
        root.addView(actions)
        root.addView(title)
        root.addView(progress, LinearLayout.LayoutParams(-1, 4))
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        webView.loadUrl("https://www.google.com")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.loadsImagesAutomatically = true
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportMultipleWindows(false)
        s.allowFileAccess = true
        s.allowContentAccess = true
        s.builtInZoomControls = false
        s.displayZoomControls = false
        s.mediaPlaybackRequiresUserGesture = true

        if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            WebSettingsCompat.setForceDark(s, WebSettingsCompat.FORCE_DARK_AUTO)
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false)

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                address.setText(url)
                title.text = view.title ?: "GG Browser"
                progress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String) {
                address.setText(url)
                title.text = view.title ?: url
                progress.visibility = View.GONE
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
            }

            override fun onReceivedTitle(view: WebView, pageTitle: String?) {
                title.text = pageTitle ?: "GG Browser"
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    request.grant(request.resources)
                }
            }
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
            val request = DownloadManager.Request(Uri.parse(url))
            request.setMimeType(mimeType)
            request.addRequestHeader("User-Agent", userAgent)
            request.setDescription("Downloading from GG Browser")
            request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
            request.setNotificationVisibility(
                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
            )
            request.setDestinationInExternalPublicDir(
                Environment.DIRECTORY_DOWNLOADS,
                URLUtil.guessFileName(url, contentDisposition, mimeType)
            )
            (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            Toast.makeText(this, "Download started", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadAddress(input: String) {
        val value = input.trim()
        if (value.isEmpty()) return

        val url = when {
            value.startsWith("http://") || value.startsWith("https://") -> value
            value.contains(".") && !value.contains(" ") -> "https://$value"
            else -> "https://www.google.com/search?q=${Uri.encode(value)}"
        }
        webView.loadUrl(url)
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }
}
